# pylint: disable=unnecessary-pass
def fib(n):
  if n == 0:
    return 0
  if n == 1:
    return 1
  if n == 5:
    return 5
  
  return []